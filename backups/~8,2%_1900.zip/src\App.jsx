import React from 'react';
import { useTimer } from './hooks/useTimer';
import KodariHeader from './components/KodariHeader';
import Timer from './components/Timer';
import Controls from './components/Controls';
import FocusChart from './components/FocusChart';

function App() {

  const { 
    timeLeft, 
    isActive, 
    sessionType, 
    toggleTimer, 
    resetTimer, 
    formatTime, 
    progress 
  } = useTimer();

  return (
    <div className="min-height-screen flex flex-col items-center justify-center p-6 bg-slate-950 overflow-hidden selection:bg-rose-500/30">
      {/* Premium background effects */}
      <div className="absolute top-0 left-0 w-[500px] h-[500px] bg-gradient-to-br from-rose-500/20 via-purple-500/10 to-transparent blur-[120px] rounded-full -translate-x-1/2 -translate-y-1/2" />
      <div className="absolute bottom-0 right-0 w-[500px] h-[500px] bg-gradient-to-tl from-emerald-500/20 via-cyan-500/10 to-transparent blur-[120px] rounded-full translate-x-1/2 translate-y-1/2" />
      
      <div className="relative z-10 flex flex-col items-center max-w-md w-full">

        <KodariHeader sessionType={sessionType} />
        <Timer 
          timeLeft={timeLeft} 
          formatTime={formatTime} 
          sessionType={sessionType} 
          progress={progress}
        />
        <Controls 
          isActive={isActive} 
          toggleTimer={toggleTimer} 
          resetTimer={resetTimer} 
          sessionType={sessionType}
        />
        
        <FocusChart />
        
        <footer className="mt-16 text-slate-600 text-sm font-medium">

          © 2024 Kodari Dev Dept. For Our CEO 🫡
        </footer>
      </div>
    </div>
  );
}

export default App;

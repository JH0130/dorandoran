/**
 * Echo-Guardian Health Risk Scoring Engine
 * Weighted 4:3:3 ratio:
 * - Environmental Factors (40%)
 * - Socio-economic Factors (30%)
 * - Bio-medical Factors (30%)
 */

export const calculateHealthRiskScore = (data) => {
  const { environmental, socioEconomic, bioMedical } = data;

  // 1. Environmental (40%) - PM2.5, PM10 based normalized score
  const envScore = (environmental.pm25 / 100) * 40; 

  // 2. Socio-economic (30%) - Living alone + income level
  let socioScore = 0;
  if (socioEconomic.livingAlone) socioScore += 15;
  if (socioEconomic.incomeLevel === 'low') socioScore += 15;

  // 3. Bio-medical (30%) - Age + chronic diseases (Special focus on Periodontitis)
  let bioScore = 0;
  if (bioMedical.age >= 65) bioScore += 10;
  
  // Clinical Note: Periodontitis is a major systemic risk for the elderly
  const hasPeriodontitis = bioMedical.chronicDiseases.includes('periodontitis');
  if (hasPeriodontitis) bioScore += 12; // Higher weight for periodontitis
  else if (bioMedical.chronicDiseases.length > 0) bioScore += 8;

  if (!bioMedical.medicationAdherence) bioScore += 8;

  const totalScore = Math.min(Math.round(envScore + socioScore + bioScore), 100);

  let status = 'green';
  if (totalScore >= 70) status = 'red';
  else if (totalScore >= 30) status = 'yellow';

  return { totalScore, status };
};

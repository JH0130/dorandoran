/**
 * Echo-Guardian AI Persona Scripts
 * Authored by Glow (Content Creator)
 */

export const onboardingScript = {
  grandchild: [
    "할머니/할아버지, 저 왔어요! 요즘 건강은 좀 어떠세요? 😊",
    "혹시 매일 챙겨 드시는 약 있으세요? 제가 까먹지 않게 도와드릴게요!",
    "요즘 자주 가시는 병원은 어디예요? 나중에 제가 대신 전화해 드릴게요! 🏥"
  ],
  doctor: [
    "반갑습니다. 당신의 AI 주치의입니다. 정확한 건강 관리를 위해 몇 가지 여쭙겠습니다. 🩺",
    "현재 복용 중인 약물의 정확한 명칭과 시간대를 알려주십시오.",
    "정기적으로 방문하시는 의료 기관의 정보를 등록해 주시기 바랍니다."
  ],
  friend: [
    "어이 친구, 잘 지냈나? 오늘 기분은 좀 어때? 🤝",
    "아픈 데는 없고? 약은 제때 잘 챙겨 먹고 있는 거지?",
    "자주 가는 단골 병원 있으면 나한테도 좀 알려줘 봐!"
  ]
};

export const dailyCheckIn = {
  grandchild: (score, status) => {
    if (status === 'red') return "할머니, 오늘 미세먼지가 너무 심해! 절대 나가지 말고, 치과에 전화 한 번 해보는 게 어때? 걱정돼서 그래요. ❤️";
    return "할머니, 오늘 날씨 좋다! 기분 좋게 하루 시작하세요! 사랑해요! ✨";
  },
  // Add other persona daily check-in scripts here...
};

import React from 'react';
import { calculateHealthRiskScore } from '../utils/healthScore';

const HealthDashboard = ({ userData, environmentalData }) => {
  const { totalScore, status } = calculateHealthRiskScore({
    environmental: environmentalData,
    socioEconomic: {
      livingAlone: userData.living_condition === 'alone',
      incomeLevel: userData.income_level
    },
    bioMedical: {
      age: userData.age,
      chronicDiseases: userData.chronic_diseases,
      medicationAdherence: true // Mocked for now
    }
  });

  const getStatusColor = (s) => {
    if (s === 'red') return 'var(--color-critical)';
    if (s === 'yellow') return 'var(--color-warning)';
    return 'var(--color-success)';
  };

  return (
    <div style={{
      padding: 'var(--spacing-section) var(--spacing-base)',
      textAlign: 'center',
      minHeight: '100vh',
      backgroundColor: 'var(--color-surface-soft)',
      color: 'var(--color-ink-deep)'
    }}>
      <div className="card-meta" style={{ maxWidth: '400px', margin: '0 auto', padding: '40px' }}>
        <h1 style={{ fontSize: 'var(--font-heading-md)', fontWeight: 700, marginBottom: '24px' }}>
          오늘의 건강 리포트
        </h1>
        
        <div style={{
          width: '280px',
          height: '280px',
          borderRadius: '50%',
          backgroundColor: '#fff',
          border: `16px solid ${getStatusColor(status)}`,
          margin: '0 auto 40px',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          transition: 'all 0.5s ease',
          boxShadow: `0 0 20px ${getStatusColor(status)}33` // Subtle glow with alpha
        }}>
          <span style={{ fontSize: 'var(--font-hero)', fontWeight: 700, color: 'var(--color-ink-deep)' }}>
            {totalScore}
          </span>
          <span style={{ fontSize: 'var(--font-heading-sm)', fontWeight: 700, color: getStatusColor(status) }}>
            {status === 'green' ? '안전' : status === 'yellow' ? '주의' : '위험'}
          </span>
        </div>

        <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
          <button className="button-pill-primary">손주와 대화하기</button>
          
          <div style={{ 
            marginTop: '20px', 
            padding: '16px', 
            backgroundColor: 'var(--color-surface-soft)', 
            borderRadius: 'var(--rounded-xl)',
            textAlign: 'left'
          }}>
            <h3 style={{ fontSize: 'var(--font-body)', fontWeight: 700, margin: '0 0 10px' }}>
              🏥 단골 병원에 전화하기
            </h3>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <div>
                <div style={{ fontWeight: 700 }}>행복한 치과</div>
                <div style={{ fontSize: '14px', color: 'var(--color-ink)' }}>최근 2주 전 방문</div>
              </div>
              <button className="button-pill-primary" style={{ padding: '8px 16px', fontSize: '14px' }}>
                📞 전화 예약
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HealthDashboard;
